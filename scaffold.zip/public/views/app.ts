import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

@NgModule({
  imports:      [ BrowserModule ]
})

class AppModule{
    constructor(){
        console.log('hui') 
    }
}
let hui = new AppModule;
 